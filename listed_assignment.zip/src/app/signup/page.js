import React from 'react';

const signup = () => {
    return (
        <div>
            Signup
        </div>
    );
};

export default signup;